//
//  HKVideoPlayerWinterTheme.m
//  iOS Video Player
//
//  Created by HK on 11/27/14.
//  Copyright (c) 2014 haikieu2907@gmail.com. All rights reserved.
//

#import "HKVideoPlayerWinterTheme.h"

@implementation HKVideoPlayerWinterTheme

@end
