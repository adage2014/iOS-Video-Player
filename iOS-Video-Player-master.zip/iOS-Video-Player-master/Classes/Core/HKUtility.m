//
//  HKUtility.m
//  iOS Video Player
//
//  Created by Hai Kieu on 12/27/14.
//  Copyright (c) 2014 haikieu2907@gmail.com. All rights reserved.
//

#import "HKUtility.h"

@implementation HKUtility

+(NSString *)iOSVersion
{
    return SYSTEM_VERSION;
}

+(UIDeviceOrientation)currentOrientation
{
    UIDeviceOrientation orientation = [[UIDevice currentDevice] orientation];
    return orientation;
}

@end
