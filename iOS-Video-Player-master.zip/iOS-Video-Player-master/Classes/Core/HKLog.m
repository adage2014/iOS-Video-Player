//
//  HKLog.m
//  iOS Video Player
//
//  Created by HK on 11/28/14.
//  Copyright (c) 2014 haikieu2907@gmail.com. All rights reserved.
//

#import "HKLog.h"

@implementation HKLog

@end
